package com.cg.project.services;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.project.beans.Mobiles;
import com.cg.project.beans.PurchaseDetails;
import com.cg.project.daoservices.MobileDAO;
import com.cg.project.daoservices.MobileDAOImpl;
public class MobileservicesImpl implements MobileServices{
	private MobileDAO mobileDAO = new MobileDAOImpl() ;
	@Override
	public PurchaseDetails acceptPurchaseDetails(String cName,String mailId,String phoneNo,int mobileId)
			throws SQLException {
		Mobiles mobiles;
		try {
			PurchaseDetails purchaseDetails=new PurchaseDetails(cName, mailId, phoneNo);
			mobileDAO.savePurchaseDetails(purchaseDetails,mobileId);
			mobiles = getMobileDetails(mobileId);
			updateMobiles(mobiles);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public Mobiles getMobileDetails(int mobileId) throws SQLException {
		return mobileDAO.getMobileDetails(mobileId);
	
	}
	@Override
	public boolean updateMobiles(Mobiles mobiles) throws SQLException {
		mobiles.setQuantity(mobiles.getQuantity()-1);
		mobileDAO.updateMobiles(mobiles);
		return false;
	}
	@Override
	public ArrayList<Mobiles> getAllMobileDetails() throws SQLException {
		return mobileDAO.getAllMobileDetails();
	}
	@Override
	public boolean deleteMobileDetails(int mobileId) throws SQLException {
		return mobileDAO.deleteMobileDetails(mobileId);
		
	}
	@Override
	public ArrayList<Mobiles> searchAllMobileDetails(float price1, float price2)
			throws SQLException {
		return mobileDAO.searchAllMobileDetails(price1, price2);
	}
}