package com.capgemini.contactbook.exceptions;
//exception handling file
@SuppressWarnings("serial")
public class ContactBookException  extends Exception{

	public ContactBookException() {
		super();

	}

	public ContactBookException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

	public ContactBookException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public ContactBookException(String message) {
		super(message);

	}

	public ContactBookException(Throwable message) {
		super(message);
	
	}

}
