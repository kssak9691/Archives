package com.capgemini.contactbook.test;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

public class ContactBookTest {

	public static ContactBookService contactBookService;
	public static ContactBookDao contactBookDAO;
	@BeforeClass
	public static void setUpBeforeClass() throws ContactBookException{
		contactBookDAO = new ContactBookDaoImpl();
		contactBookService = new ContactBookServiceImpl();
	}

	@Test
	public void testAddDemandDraftDetails() throws SQLException {
		contactBookDAO = new ContactBookDaoImpl();
		contactBookService = new ContactBookServiceImpl();
		try{
			int enquiryNo = contactBookService.addEnquiry(new EnquiryBean("PRATEEK", "JAIN", "9903153097",	"FULL STACK","JAVA"));
			assertTrue(enquiryNo>1001);
		}catch(ContactBookException e){
			System.err.println("Wrong test parameter");
		}
	}
}

