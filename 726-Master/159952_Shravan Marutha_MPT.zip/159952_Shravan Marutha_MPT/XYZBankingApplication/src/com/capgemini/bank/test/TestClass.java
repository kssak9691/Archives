package com.capgemini.bank.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestClass {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
