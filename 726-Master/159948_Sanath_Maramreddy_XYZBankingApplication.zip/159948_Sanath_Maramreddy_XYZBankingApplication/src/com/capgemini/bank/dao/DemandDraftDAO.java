package com.capgemini.bank.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.ConnectionProvider;
public class DemandDraftDAO implements IDemandDraftDAO{
	private Connection conn=ConnectionProvider.getDBConnection();
	//sql operations are done here in the try catch catch and block including insert date and get data
	private final static Logger LOGGER = 
			Logger.getLogger(Logger.GLOBAL_LOGGER_NAME); 
	LogManager lgmngr = LogManager.getLogManager(); 
	Logger log = lgmngr.getLogger(Logger.GLOBAL_LOGGER_NAME); 
	//log.log(Level.INFO, "This is a log message"); 

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException{
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("insert into demand_draft(transaction_id,customer_name,in_favor_of, phone_number,date_of_transaction,dd_amount,dd_description) values(Transaction_Id_Seq.nextval,?,?,?,?,?,?)");
			pstmt1.setString(1, demandDraft.getCustomer_name());
			pstmt1.setString(2, demandDraft.getIn_favor_of());
			pstmt1.setString(3,demandDraft.getPhone_number());
			pstmt1.setDate(4,demandDraft.getDate_of_transaction());
			pstmt1.setInt(5, demandDraft.getDd_amount());
			pstmt1.setString(6, demandDraft.getDd_description());
			pstmt1.executeUpdate();
			PreparedStatement pstmt2=conn.prepareStatement("select max(transaction_id) from demand_draft");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			int transaction_id=rs.getInt(1);
			conn.commit();
			demandDraft.setTransaction_id(transaction_id);
			return transaction_id;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transaction_id){
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("select * from demand_draft where transaction_id="+transaction_id);
			ResultSet demandDraftrs = pstmt1.executeQuery();
			if(demandDraftrs.next()){
				String customer_name=demandDraftrs.getString("customer_name");
				String in_favor_of=demandDraftrs.getString("in_favor_of");
				String phone_number=demandDraftrs.getString("phone_number");
				Date date_of_transaction=demandDraftrs.getDate("date_of_transaction");
				int dd_amount=demandDraftrs.getInt("dd_amount");
				int dd_commission=demandDraftrs.getInt("dd_commission");
				String dd_description=demandDraftrs.getString("dd_description");
				DemandDraft demandDraft=new DemandDraft(customer_name, in_favor_of, phone_number, date_of_transaction, dd_amount, dd_commission, dd_description);
				conn.commit();
				return demandDraft;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public boolean updateDemandDraft(DemandDraft demandDraft) throws SQLException{
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("Update demand_draft set dd_commission = ? where transaction_id="+demandDraft.getTransaction_id());
			pstmt1.setInt(1,demandDraft.getDd_commission());
			int flag=pstmt1.executeUpdate();
			conn.commit();
			if (flag > 0)	return true;
			else	return false;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}
}