package com.cg.project.daoservices;
import java.util.ArrayList;
import com.cg.project.beans.*;
public interface AccountDAO {
	Account save(Account account);
	Account getAccountDetails(long accountNo);
	ArrayList<Account> getAllAccountDetails();
	ArrayList<Transaction> getAllTransactionDetails(long accountNo);
	boolean update(Account account);
	boolean update(Transaction transaction);
}