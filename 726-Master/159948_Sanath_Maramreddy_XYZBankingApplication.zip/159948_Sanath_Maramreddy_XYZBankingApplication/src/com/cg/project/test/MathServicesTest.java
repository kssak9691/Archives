package com.cg.project.test;
import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.service.IDemandDraftService;
import com.cg.project.exception.*;
import com.cg.project.mathservices.*;
public class MathServicesTest {
	static IDemandDraftDAO mathServices;
	@BeforeClass
	public static void setUPTestEnvy(){
		mathServices=new IDemandDraftService() {
			
			@Override
			public DemandDraft getDemandDraftDetails(int transaction_id)
					throws SQLException {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public int calculateCommision(int transaction_id) {
				// TODO Auto-generated method stub
				return 0;
			}
			
			@Override
			public int addDemandDraftDetails(DemandDraft demandDraft) {
				// TODO Auto-generated method stub
				return 0;
			}
		}
	}
}

		
	