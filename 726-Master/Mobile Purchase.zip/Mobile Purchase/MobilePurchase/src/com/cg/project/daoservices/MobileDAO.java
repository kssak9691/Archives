package com.cg.project.daoservices;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.project.beans.*;
public interface MobileDAO {
	PurchaseDetails savePurchaseDetails(PurchaseDetails purchaseDetails,int mobileId) throws SQLException;
	Mobiles getMobileDetails(int mobileId) throws SQLException;
	boolean updateMobiles(Mobiles mobiles) throws SQLException;
	ArrayList<Mobiles> getAllMobileDetails() throws SQLException;
	boolean deleteMobileDetails(int mobileId) throws SQLException;
	ArrayList<Mobiles> searchAllMobileDetails(float price1,float price2) throws SQLException;
}