package com.capgemini.bank.exception;

public class AmountInvalidException extends Exception {

}
