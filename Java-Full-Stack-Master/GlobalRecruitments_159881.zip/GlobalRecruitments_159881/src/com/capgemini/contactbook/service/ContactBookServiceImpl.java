package com.capgemini.contactbook.service;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService{
	//creating a variable of dao class
	static ContactBookDao contactBookDao= new ContactBookDaoImpl();
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException, SQLException {
		try{
			//calling the dao class and storing the return value in enquiryNo
			int enquiryNo=contactBookDao.addEnquiry(enqry);
			enqry.setEnqryId(enquiryNo);
			return enquiryNo;
		}
		catch(ContactBookException e){
			throw e;
		}
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException, SQLException {
		try{
			//calling dao class to getEnquiryDetails
			EnquiryBean enqry = contactBookDao.getEnquiryDetails(EnquiryID);
			return enqry;
		}
		catch(ContactBookException e){
			throw e;
		}
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		return true;
	}
}