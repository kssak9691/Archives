package com.capgemini.bank.service;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
public interface IDemandDraftService {
	int addDemandDraftDetails (DemandDraft demandDraft);
	DemandDraft getDemandDraftDetails (int transaction_id) throws SQLException;
	int calculateCommision(int transaction_id);
}