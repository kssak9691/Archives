package com.cg.banking.services;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.banking.beans.*;
import com.cg.banking.daoservices.*;
import com.cg.banking.exceptions.*;
public class BankingServicesImpl implements BankingServices {
	private AccountDAO accountDAO=new AccountDaoImpl();
	@Override
	public long openAccount(String accountType, float initBalance,int pinNumber,String status)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account=new Account(pinNumber,accountType,status,initBalance);
		try {
			accountDAO.saveAccountDetails(account);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return account.getAccountNo();
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account;
		try {
			account = getAccountDetails(accountNo);
			account.setAccountBalance(account.getAccountBalance()+amount);
			accountDAO.updateTransaction(accountNo,amount,"Deposit");
			accountDAO.updateAccount(account);
			return account.getAccountBalance();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account;
		try {
			account = getAccountDetails(accountNo);
			if(account.getAccountBalance()-amount>1000&&account.getPinNumber()==pinNumber){
				account.setAccountBalance(account.getAccountBalance()-amount);
				accountDAO.updateTransaction(accountNo,amount,"Withdraw");
				accountDAO.updateAccount(account);
			}
			else
				System.out.println("Insufficient Balance!!Withdrawal Failed");
			return account.getAccountBalance();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account account1;
		try {
			account1 = getAccountDetails(accountNoTo);
			Account account2=getAccountDetails(accountNoFrom);
			if(account2.getAccountBalance()-transferAmount>1000&&account2.getPinNumber()==pinNumber){
				account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
				account2.setAccountBalance(account2.getAccountBalance()-transferAmount);
				accountDAO.updateTransaction(accountNoTo,transferAmount,"Transfer");
				accountDAO.updateTransaction(accountNoFrom,transferAmount,"Transfer");
				accountDAO.updateAccount(account1);
				accountDAO.updateAccount(account2);
			}
			else
				System.out.println("Insufficient Balance!!Withdrawal Failed");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException, SQLException {
		Account account=accountDAO.getAccountDetails(accountNo);
		if(account==null) throw new AccountNotFoundException("Sorry!! Account Details Not Found");
		return account;	
	}
	@Override
	public ArrayList<Account> getAllAccountDetails() throws BankingServicesDownException{	
		return accountDAO.getAllAccountDetails();
	}
	@Override
	public ArrayList<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException{	
		return accountDAO.getAccountAllTransactionDetails(accountNo);
	}
	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException{
		return accountDAO.getAccountStatus(accountNo);
	}
}