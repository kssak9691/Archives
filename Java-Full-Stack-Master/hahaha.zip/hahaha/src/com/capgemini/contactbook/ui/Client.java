package com.capgemini.contactbook.ui;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.exception.ContactNoException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;
public class Client {
	static Scanner k=new Scanner(System.in);
	public static void main(String[] args) throws SQLException, ContactBookException, ContactNoException {
		ContactBookService contactBookService = new ContactBookServiceImpl();
		int choice;
		String firstName,lastName,contactNumber,preferedDomain,preferedLocation;
		int enquiryNo;
		int flag=1;
		//please create a service layer object and call all the prefered methods where comments are mentioned
		while(flag==1){
		System.out.println("***********************Global Recruitments*******************\n");
		System.out.println("Choose an operation\n1.Enter Enquiry Details\n2.View Enquiry Details on Id\n0.Exit\n");
		System.out.println("Please Enter a choice:");
		choice=k.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter First Name:");
			firstName=k.next();
			System.out.println("Enter Last Name:");
			lastName=k.next();
			System.out.println("Enter Contact Number:");
			contactNumber=k.next();
			System.out.println("Enter Prefered Domain:");
			preferedDomain=k.next();
			System.out.println("Enter Prefered Location :");
			preferedLocation=k.next();
			EnquiryBean bean = new EnquiryBean(firstName, lastName, contactNumber, preferedLocation, preferedDomain);
			System.out.println("Thank you "+firstName+" "+lastName+" your Unique Id is "+contactBookService.addEnquiry(bean)+" we will contact you shortly");
			break;

		case 2:
			System.out.println("Enter the Enquiry No: ");
			enquiryNo=k.nextInt();
			System.out.println(contactBookService.getEnquiryDetails(enquiryNo).toString());
			//we have to call getEnquiryDetails method from services class
			break;
		case 0:
			System.out.println("Thank you selecting us!!");
			flag=0;
			break;
		default:
			System.out.println("Enter a valid option");
			break;
		}}

		

	}

}