package com.capgemini.bank.service;
import java.sql.SQLException;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.*;
public class DemandDraftService implements IDemandDraftService{
	private IDemandDraftDAO idemandDraftDAO=new DemandDraftDAO();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft){
		try{
		return idemandDraftDAO.addDemandDraftDetails(demandDraft);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transaction_id) throws SQLException{
		DemandDraft demandDraft = idemandDraftDAO.getDemandDraftDetails(transaction_id);
		return demandDraft;
	}
	@Override
	public int calculateCommision(int transaction_id) {
		try{
		DemandDraft demandDraft=idemandDraftDAO.getDemandDraftDetails(transaction_id);
		if(demandDraft.getDd_amount()<=5000){
			demandDraft.setDd_commission(10);
		}
		else if(demandDraft.getDd_amount()>=5001 && demandDraft.getDd_amount()<=10000){
			demandDraft.setDd_commission(41);
		}
		else if(demandDraft.getDd_amount()>=10001 && demandDraft.getDd_amount()<=100000){
			demandDraft.setDd_commission(51);
		}
		else if(demandDraft.getDd_amount()>=100001 && demandDraft.getDd_amount()<=500000){
			demandDraft.setDd_commission(306);
		}
		idemandDraftDAO.updateDemandDraft(demandDraft);
		return demandDraft.getDd_commission();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
}