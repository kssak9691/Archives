package com.cg.payroll.exception;

public class PayrollServicesDownException extends Exception{

}
