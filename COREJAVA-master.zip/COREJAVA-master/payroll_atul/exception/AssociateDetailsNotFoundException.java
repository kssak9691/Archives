package com.cg.payroll.exception;

public class AssociateDetailsNotFoundException extends Exception{

}
