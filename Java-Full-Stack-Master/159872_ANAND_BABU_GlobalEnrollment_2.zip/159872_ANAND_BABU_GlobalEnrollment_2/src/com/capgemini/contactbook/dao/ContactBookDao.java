package com.capgemini.contactbook.dao;
import java.sql.SQLException;
import com.igate.contactbook.bean.EnquiryBean;
public interface ContactBookDao {
	public int  addEnquiry(EnquiryBean enqry) throws SQLException;
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws SQLException;
}


