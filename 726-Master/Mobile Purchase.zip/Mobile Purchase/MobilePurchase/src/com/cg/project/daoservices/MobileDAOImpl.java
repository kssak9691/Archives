package com.cg.project.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.project.beans.Mobiles;
import com.cg.project.beans.PurchaseDetails;
import com.cg.project.util.ConnectionProvider;
public class MobileDAOImpl implements MobileDAO{
	private Connection conn=ConnectionProvider.getDBConnection();
	@Override
	public PurchaseDetails savePurchaseDetails(PurchaseDetails purchaseDetails,int mobileId)
			throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("INSERT INTO PurchaseDetails(purchaseId,cName,mailId,phoneNo,purchaseDate,mobileId) VALUES(seq_purchaseId.nextval,?,?,?,sysdate,?)");
			pstmt1.setString(1,purchaseDetails.getcName());
			pstmt1.setString(2, purchaseDetails.getMailId());
			pstmt1.setString(3, purchaseDetails.getPhoneNo());
			pstmt1.setInt(4, mobileId);
			pstmt1.executeUpdate();
			PreparedStatement pstmt2=conn.prepareStatement("SELECT MAX(purchaseId) FROM PurchaseDetails");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			int purchaseId=rs.getInt(1);
			conn.commit();
			purchaseDetails.setPurchaseId(purchaseId);
			return purchaseDetails;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}
	@Override
	public Mobiles getMobileDetails(int mobileId) throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("SELECT * FROM Mobiles WHERE mobileId="+mobileId);
			ResultSet mobilers = pstmt1.executeQuery();
			if(mobilers.next()){
				String name=mobilers.getString("name");
				float price=mobilers.getFloat("price");
				int quantity=mobilers.getInt("quantity");
				Mobiles mobiles=new Mobiles(mobileId, name, price, quantity);
				conn.commit();
				return mobiles;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public boolean updateMobiles(Mobiles mobiles) throws SQLException {
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("UPDATE Mobiles SET quantity = ? where mobileId="+mobiles.getMobileId());
			pstmt1.setInt(1,mobiles.getQuantity());
			int flag=pstmt1.executeUpdate();
			conn.commit();
			if (flag > 0)	return true;
			else	return false;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}
	@Override
	public ArrayList<Mobiles> getAllMobileDetails() throws SQLException {
		try {
			conn.setAutoCommit(false);
			ArrayList<Mobiles> mobiles=new ArrayList<>();
			PreparedStatement pstmt1=conn.prepareStatement("SELECT * FROM Mobiles");
			ResultSet mobilers=pstmt1.executeQuery();
			while(mobilers.next()){
				int mobileId=mobilers.getInt("mobileId");
				String name=mobilers.getString("name");
				float price=mobilers.getFloat("price");
				int quantity=mobilers.getInt("quantity");
				Mobiles mobile=new Mobiles(mobileId, name, price, quantity);
				conn.commit();
				mobiles.add(mobile);
			}
			return mobiles;
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return null;
	}
	@Override
	public boolean deleteMobileDetails(int mobileId) throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("DELETE  FROM Mobiles WHERE mobileId="+mobileId);
			pstmt1.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return false;
	}
	@Override
	public ArrayList<Mobiles> searchAllMobileDetails(float price1, float price2)
			throws SQLException {
		try{
			conn.setAutoCommit(false);
			ArrayList<Mobiles> mobiles=new ArrayList<>();
			PreparedStatement pstmt1=conn.prepareStatement("SELECT * FROM Mobiles WHERE price>="+price1+" AND price<="+price2);
			ResultSet mobilers=pstmt1.executeQuery();
			while(mobilers.next()){
				int mobileId=mobilers.getInt("mobileId");
				String name=mobilers.getString("name");
				float price=mobilers.getFloat("price");
				int quantity=mobilers.getInt("quantity");
				Mobiles mobile=new Mobiles(mobileId, name, price, quantity);
				conn.commit();
				mobiles.add(mobile);
			}
			return mobiles;
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return null;
	}
}