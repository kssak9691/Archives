package com.capgemini.contactbook.dao;
import java.sql.SQLException;
import com.igate.contactbook.bean.*;
public interface ContactBookDAO {
	public int addEnquiry(EnquiryBean enqry) throws SQLException;
	EnquiryBean getEnquiryDetails(int EnquiryID) throws SQLException;
}