package com.capgemini.contactbook.service;
import java.sql.SQLException;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.exception.ContactNoException;
import com.igate.contactbook.bean.EnquiryBean;
public interface ContactBookService {
	public int addEnquiry(EnquiryBean bean) throws SQLException, ContactBookException, ContactNoException;
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException,SQLException;
	public boolean isValidEnquiry(EnquiryBean bean) throws ContactBookException,SQLException, ContactNoException;
}
