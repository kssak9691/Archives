package com.cg.bank.test;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exceptions.BankingException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class DemandDraftDAOTest {
	public static IDemandDraftService demandDraftService;
	public static IDemandDraftDAO demandDraftDAO;
	@BeforeClass
	public static void setUpBeforeClass() throws BankingException{
		demandDraftDAO = new DemandDraftDAO();
		demandDraftService = new DemandDraftService();
	}
	
	@Test
	public void testAddDemandDraftDetails() throws SQLException {
		demandDraftDAO = new DemandDraftDAO();
		demandDraftService = new DemandDraftService();
		//demandDraftService.addDemandDraftDetails(new DemandDraft("John", "Capgemini", "new",	 "9665612647", 2500));
		try{
			int n = demandDraftService.addDemandDraftDetails(new DemandDraft("John", "Capgemini", "new",	 "9665612647", 2500));
			assertTrue(n>1001);
		}catch(BankingException e){
			System.err.println("Wrong test parameter");
		}
	}
}
