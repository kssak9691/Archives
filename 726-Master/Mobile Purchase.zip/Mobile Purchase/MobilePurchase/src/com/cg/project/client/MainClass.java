package com.cg.project.client;
import java.sql.SQLException;
import com.cg.project.services.MobileServices;
import com.cg.project.services.MobileservicesImpl;
public class MainClass {
	public static void main(String[] args) throws SQLException {
		
		MobileServices mobileServices = new MobileservicesImpl();
		
		System.out.println((mobileServices.getAllMobileDetails().toString()));
		
		mobileServices.acceptPurchaseDetails("Venkat","venkat@gmail.com","9652452427",1002);

		System.out.println(mobileServices.getMobileDetails(1001).toString());

		System.out.println(mobileServices.searchAllMobileDetails(5000, 15000));

		mobileServices.deleteMobileDetails(1005);

	}
}