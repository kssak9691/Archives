package com.capgemini.contactbook.service;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.capgemini.contactbook.dao.ContactBookDAO;
import com.capgemini.contactbook.dao.ContactBookDAOImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;
public class ContactBookServiceImpl implements ContactBookService{
	private ContactBookDAO contactBookDAO=new ContactBookDAOImpl();
	@Override
	public int addEnquiry(EnquiryBean enqry) throws SQLException, ContactBookException {
		
		isValidEnquiry(enqry);
		return contactBookDAO.addEnquiry(enqry);
	}
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws SQLException {
		return contactBookDAO.getEnquiryDetails(EnquiryID);
	}
	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) throws SQLException,
	ContactBookException {
		validateFirstname(enqry.getfName());
		validateLastname(enqry.getlName());
		validateContactNo(enqry.getContactNo());
		validatePDomain(enqry.getpDomain());
		validatePLocation(enqry.getpLocation());
		return true;
	}
	public boolean validateContactNo(String contactNo) throws ContactBookException {
		Pattern p = Pattern.compile("[7-9][0-9]{9}");
		Matcher m = p.matcher(contactNo); 
		if((m.find() && m.group().equals(contactNo))==false)
			throw new ContactBookException("PLEASE CHECK YOUR MOBILE NUMBER");
		else
			return (m.find() && m.group().equals(contactNo));
	}
	public boolean validateFirstname(String fName) throws ContactBookException{
		if(fName.matches("[a-zA-Z]+")==false)
			throw new ContactBookException("PLEASE CHECK YOUR FIRST NAME");
		else
			return fName.matches("[a-zA-Z]+");
	}
	public boolean validateLastname(String lName) throws ContactBookException{
		if(lName.matches("[a-zA-Z]+")==false)
			throw new ContactBookException("PLEASE CHECK YOUR LAST NAME");
		else
			return lName.matches("[a-zA-Z]+");
	}
	public boolean validatePLocation(String pLocation) throws ContactBookException{
		if(pLocation.matches("[a-zA-Z]+")==false)
			throw new ContactBookException("PLEASE CHECK YOUR LOCATION");
		else
			return pLocation.matches("[a-zA-Z]+");
	}
	public boolean validatePDomain(String pDomain) throws ContactBookException{
		if(pDomain.matches("[a-zA-Z]+")==false)
			throw new ContactBookException("PLEASE CHECK YOUR DOMAIN");
		else
			return pDomain.matches("[a-zA-Z]+");
	}
}