package com.capgemini.contactbook.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.util.*;

public final class Client {

	private static Scanner in;

	public static void main(String[] args) throws SQLException {
		//checking whether connection is done or not
		if (ConnectionProvider.getDbConnection()!=null)
			//System.out.println("Connection done");
		//Menu display line
		System.out.println("********************Global Recruitments*****************\nChoose an Operation\n1.Enter Enquiry Details\n2.View Enquiry Details on Id\n0.Exit\n********************\nPlease enter a choice:");
		in = new Scanner(System.in);
		int num=in.nextInt();
		EnquiryBean enquiryBean = new EnquiryBean();
		ContactBookService contactBookService = new ContactBookServiceImpl();
		switch(num){
		case 0:{
			System.out.println("Thank you for selecting us!!");
			break;
		}
		//accepting details to enter into database
		case 1:{
			System.out.println("Enter First Name :");
			enquiryBean.setfName(in.next());
			System.out.println("Enter Last Name :");
			enquiryBean.setlName(in.next());
			System.out.println("Enter Contact Number :");
			enquiryBean.setContactNo(in.next());
			System.out.println("Enter Preferred Domain  :");
			enquiryBean.setpDomain(in.next());
			System.out.println("Enter Preferred Location :");
			enquiryBean.setpLocation(in.next());
			try {
				contactBookService.isValidEnquiry(enquiryBean);
				int enquiryNo=contactBookService.addEnquiry(enquiryBean);
				System.out.println("Thank you "+enquiryBean.getfName()+" "+enquiryBean.getlName() + " your Unique Id is "+enquiryNo+" we will contact you shortly ");
			} catch (ContactBookException e) {
				e.printStackTrace();
			}
			break;
		}
		//accepting enquiryNo to search in database
		case 2:{
			EnquiryBean enquiryBean1 = new EnquiryBean();
			System.out.println("Enter the Enquiry No. : ");
			int enqryNo=in.nextInt();
			try {
				enquiryBean1=contactBookService.getEnquiryDetails(enqryNo);
				System.out.println(enquiryBean1);
			} catch (ContactBookException e) {
				System.out.println("Sorry no details found!!");
			}
			break;
		}
		default:
			System.out.println("Enter a valid number");
		}
	}

}
