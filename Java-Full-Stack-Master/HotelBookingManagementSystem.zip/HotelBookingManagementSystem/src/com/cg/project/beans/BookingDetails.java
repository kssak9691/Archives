package com.cg.project.beans;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class BookingDetails{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int bookingId;  
	private Date bookedFromDate;
	private Date bookedToDate;
	private int noOfAdult;
	private int noOfChildren;
	private float amount;
	@ManyToOne
	private Users users;
	@ManyToOne
	private Hotel hotel;
	@ManyToOne
	private RoomDetails roomDetails;
	//constructor parameterized and non parameterized....
	public BookingDetails() {
		super();
	}
	
}