package com.cg.fileIO;

import java.io.File;

public class MainClass {

	public static void main(String[] args) {
		File file = new File("E:\\Oracle_Learning\\Test1.txt");
		

	}

}
