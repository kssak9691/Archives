package com.capgemini.bank.exceptions;

@SuppressWarnings("serial")
public class BankingServicesDownException extends Exception{

	public BankingServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankingServicesDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BankingServicesDownException(String message) {
		super(message);

	}

	public BankingServicesDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}


	
}
