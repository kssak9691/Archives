package lab2;

public class Lab2_1 {
	
	public static void main(String[] args) {
		PersonDetails person1 = new PersonDetails("Divya", "Bharathi", 'F', 20, 85.55);
		System.out.println(person1);
	}

}
