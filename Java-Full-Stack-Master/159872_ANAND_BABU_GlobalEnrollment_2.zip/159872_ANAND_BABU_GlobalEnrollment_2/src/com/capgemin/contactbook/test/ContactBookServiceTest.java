package com.capgemin.contactbook.test;

import static org.junit.Assert.*;

import java.sql.SQLException;



import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.exception.ContactNoException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Test;

import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceTest {
     public static ContactBookDao contactBookDao ;
     public static ContactBookService contactBookService ;
     @BeforeClass
 	public static void setUpBeforeClass() throws SQLException{
     contactBookService = new ContactBookServiceImpl() ;
 	}
     @Test
 	public void testAddEnquiry() throws SQLException, ContactBookException, ContactNoException {
    	
    	 	contactBookService = new ContactBookServiceImpl() ;
 		try{
 			int n = contactBookService.addEnquiry( new EnquiryBean("anandbabu", "bukkapindla", "7989721253","hyderabad", "seniorAnalyst"));
 			assertTrue(n>1001);
 		}catch(SQLException e){
 			System.err.println("Wrong test parameter");
 		}
 	}

}