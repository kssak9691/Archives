package com.capgemini.bank.ui;
import java.util.Scanner;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.*;
public class Client {
	static Scanner k=new Scanner(System.in);
	public static void main(String[] args) {
		IDemandDraftService iDemandDraftService=new DemandDraftService();
		System.out.println("Enter the name of the customer : ");
		String customer_name=k.next();
		System.out.println("Enter customer phone number: ");
		String phone_number=k.next();
		System.out.println("in favor of : ");
		String in_favor_of=k.next();
		System.out.println("Enter Demand Draft amount : ");
		int dd_amount=k.nextInt();
		System.out.println("Enter Remarks : ");
		String dd_description=k.next();
		DemandDraft demandDraft1=new DemandDraft(customer_name, in_favor_of, phone_number, dd_amount, dd_description);
		int transaction_id=iDemandDraftService.addDemandDraftDetails(demandDraft1);
		iDemandDraftService.calculateCommision(transaction_id);
		System.out.println("Your Demand Draft request has been successfully registered along with the "+transaction_id);
	}
}