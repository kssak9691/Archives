package com.cg.project.client;
import com.cg.project.beans.*;
import com.cg.project.services.*;
public class MainClass {
	public static void main(String[] args) {
		PayrollServices payrollServices = new PayrollServicesImpl();
		int associateId=payrollServices.acceptAssociateDetails(10000,"David","Billa","CSE","Sr.Con","CWD0707","david@gmail.com" ,202366,"HDFC","HDFC357355",20000,1000,2000);
		payrollServices.calculateNetSalary(associateId);
		Associate associate=payrollServices.getAssociateDetails(associateId);
		System.out.println(associate.toString());
	}
}