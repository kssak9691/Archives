package com.cg.project.services;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.project.beans.Mobiles;
import com.cg.project.beans.PurchaseDetails;
public interface MobileServices {
	Mobiles getMobileDetails(int mobileId) throws SQLException;
	boolean updateMobiles(Mobiles mobiles) throws SQLException;
	ArrayList<Mobiles> getAllMobileDetails() throws SQLException;
	boolean deleteMobileDetails(int mobileId) throws SQLException;
	ArrayList<Mobiles> searchAllMobileDetails(float price1,float price2) throws SQLException;
	PurchaseDetails acceptPurchaseDetails(String cName, String mailId,
			String phoneNo, int mobileId)
			throws SQLException;
}