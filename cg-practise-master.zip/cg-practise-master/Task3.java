
public class Task3 {
	public int solution(int[] A)
	{
		int minCost=0;
		for(int i=1;i<A.length-3;i++)
			for(int j=i+2;j<A.)
	}
	public static void main(String[] args) {


	}

}
