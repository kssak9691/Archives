package com.capgemini.contactbook.service;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.exception.ContactNoException;
import com.igate.contactbook.bean.EnquiryBean;
public class ContactBookServiceImpl implements ContactBookService{
	ContactBookDao dao = new ContactBookDaoImpl();
	@Override
	public int addEnquiry(EnquiryBean bean) throws ContactBookException,SQLException, ContactNoException {
		isValidEnquiry(bean);
		return dao.addEnquiry(bean);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException,SQLException {
		return dao.getEnquiryDetails(EnquiryID);
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean bean) throws ContactBookException,SQLException, ContactNoException {


		
		validateFirstname(bean.getfName());
		validateLastname(bean.getlName());
		validateContactNo(bean.getContactNo());
		validatePDomain(bean.getpDomain());
		validatePLocation(bean.getpLocation());
		return true;
	}

	public boolean validateContactNo(String contactNo) throws ContactBookException, ContactNoException{
		Pattern p = Pattern.compile("[7-9][0-9]{9}");
		Matcher m = p.matcher(contactNo); 
		if((m.find() && m.group().equals(contactNo))==false)
			throw new ContactNoException("please check your mobile number");
		else
			return (m.find() && m.group().equals(contactNo));

	}
	public boolean validateFirstname(String fName) throws ContactBookException{
		if(fName.matches("[a-zA-Z]+")==false)
			throw new ContactBookException("Please check your firstname");
		else
			return fName.matches("[a-zA-Z]+");
	}
	public boolean validateLastname(String lName) throws ContactBookException{
		if(lName.matches("[a-zA-Z]+")==false)
			throw new ContactBookException("Please check your lastname");
		else
			return lName.matches("[a-zA-Z]+");}
	public boolean validatePLocation(String pLocation) throws ContactBookException{
		if(pLocation.matches("[a-zA-Z]+")==false)
			throw new ContactBookException("Please check your location name");
		else
			return pLocation.matches("[a-zA-Z]+");}
	public boolean validatePDomain(String pDomain) throws ContactBookException{
		if(pDomain.matches("[a-zA-Z]+")==false)
			throw new ContactBookException("Please check your domain name");
		else
			return pDomain.matches("[a-zA-Z]+");}



}
