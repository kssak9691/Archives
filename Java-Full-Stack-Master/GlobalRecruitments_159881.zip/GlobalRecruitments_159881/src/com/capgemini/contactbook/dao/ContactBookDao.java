package com.capgemini.contactbook.dao;
import java.sql.SQLException;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;
//interface Dao
public interface ContactBookDao {
	public int addEnquiry(EnquiryBean enquiry) throws ContactBookException, SQLException;
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException, SQLException;
}
