package com.capgemini.contactbook.ui;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;
public class MainClass {
	static Scanner k=new Scanner(System.in);
	public static void main(String[] args) throws SQLException, ContactBookException {
		int choice,enquiryNo,flag=1;
		String fName,lName,contactNo,pDomain,pLocation;
		ContactBookService contactBookService=new ContactBookServiceImpl();
		System.out.println("***********************Global Recruitments*******************\n");
		while(flag>0){
			System.out.println("Choose an operation\n1.Enter Enquiry Details\n2.View Enquiry Details on Id\n0.Exit\n");
			System.out.println("Please Enter a choice:");
			choice=k.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter First Name:");
				fName=k.next();
				System.out.println("Enter Last Name:");
				lName=k.next();
				System.out.println("Enter Contact Number:");
				contactNo=k.next();
				System.out.println("Enter Prefered Domain:");
				pDomain=k.next();
				System.out.println("Enter Prefered Location :");
				pLocation=k.next();
				EnquiryBean enquiryBean=new EnquiryBean(fName, lName, contactNo, pLocation, pDomain);
				System.out.println("Thank you "+fName+" "+lName+" your Unique Id is "+contactBookService.addEnquiry(enquiryBean)+" we will contact you shortly");
				break;
			case 2:
				System.out.println("Enter the Enquiry No: ");
				enquiryNo=k.nextInt();
				System.out.println(contactBookService.getEnquiryDetails(enquiryNo));
				break;
			case 0:
				System.out.println("Thank you selecting us!!");
				flag=0;
				break;
			default:
				break;
			}
		}
	}
}