package com.cg.project.dao;

import java.util.ArrayList;

import com.cg.project.beans.Hotel;
import com.cg.project.beans.RoomDetails;
import com.cg.project.beans.Users;

public interface CustomerDAO {
	Users save(Users user);
	boolean findOne(String userName);
	ArrayList<Hotel>findAllHotels();
	ArrayList<RoomDetails>findAllRooms(int hotelId);
}
