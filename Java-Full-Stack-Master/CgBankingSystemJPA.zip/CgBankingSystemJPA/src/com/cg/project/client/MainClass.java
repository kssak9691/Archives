package com.cg.project.client;
import com.cg.project.services.*;
public class MainClass {
	public static void main(String[] args) {
		BankingServices services=new BankingServicesImpl();

		long accountNo1=services.openAccount("Savings", 15000,1234,"Active");
		System.out.println(accountNo1);

		long accountNo2=services.openAccount("Current", 5000, 2345, "Active");
		System.out.println(accountNo2);


		/*
		services.openAccount("Salary", 10000,3465,"Active");
		 */

		/*
		float accountBalance=services.depositAmount(2, 2000);
		System.out.println(accountBalance);
		*/

		/*
		float accountBalance=services.withdrawAmount(1, 1000, 1234);
		System.out.println(accountBalance);
		*/
		
		/*
		services.fundTransfer(111112, 111111, 1000, 1234);
		*/

		/*
			System.out.println(services.accountStatus(111114));
			System.out.println(services.getAccountAllTransaction(111114).toString());
		 */

	}
}