package com.cg.payroll.client;
import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.*;
import com.cg.payroll.services.*;
public class MainClass {
	public static void main(String[] args) throws PayrollServicesDownException,AssociateDetailsNotFoundException{
		PayrollServices payrollServices = new PayrollServicesImpl();
		int associateId=payrollServices.acceptAssociateDetails(2000,"Virat","Kaushik","CSE","Sr.Con","357355","sbf254@gmail.com" ,991,"HDFC","HDFC357355",1856431, 1544,165743);
		payrollServices.calculateNetSalary(associateId);
		Associate associate=payrollServices.getAssociateDetails(associateId);
		System.out.println(associate.toString());
	}
}