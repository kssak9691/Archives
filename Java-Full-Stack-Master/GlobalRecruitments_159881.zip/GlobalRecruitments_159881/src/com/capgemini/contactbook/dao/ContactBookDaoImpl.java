package com.capgemini.contactbook.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.util.ConnectionProvider;


public class ContactBookDaoImpl implements ContactBookDao{
	Logger logger = Logger.getLogger(ContactBookDao.class);
	private Connection conn=ConnectionProvider.getDbConnection();
	@Override
	public int addEnquiry(EnquiryBean enquiry) throws ContactBookException, SQLException {
		try {
			//updating the details in database
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("INSERT INTO enquiry values(enquiries.nextval,?,?,?,?,?)");
			pstmt1.setString(1, enquiry.getfName());
			pstmt1.setString(2, enquiry.getlName());
			pstmt1.setString(3, enquiry.getContactNo());
			pstmt1.setString(4, enquiry.getpDomain());
			pstmt1.setString(5,enquiry.getpLocation());
			pstmt1.executeUpdate();
			conn.commit();
			PreparedStatement pstmt2 = conn.prepareStatement("select max(enqryId) from enquiry");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			int enqryId=rs.getInt(1);
			//logging the successful entry of details
			logger.info("Details added with id "+enqryId);
			return enqryId;
		} catch (SQLException e) {
			logger.error(e.getMessage()+" "+e.getErrorCode());
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException, SQLException {
		try {
			//getting details from database
			PreparedStatement pstmt1 = conn.prepareStatement("Select * from enquiry where enqryId="+EnquiryID);
			ResultSet rs=pstmt1.executeQuery();
			if(rs.next()){
				//retrieving the details from database and saving it in EnquiryBean
				EnquiryBean enquiryBean= new EnquiryBean(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6));
				logger.info("Details found and returned of enquiryId"+EnquiryID);
				return enquiryBean;
			}
			else
				throw new ContactBookException();
		} catch (SQLException e) {
			//throwing error message Error handling
			logger.error(e.getMessage()+" "+e.getErrorCode());
			throw e;
		}
	}
}

