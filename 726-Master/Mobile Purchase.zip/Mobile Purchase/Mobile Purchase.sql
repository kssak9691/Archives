CREATE TABLE Mobiles (
mobileId NUMBER,
CONSTRAINT pk_mobileId PRIMARY KEY(mobileId), 
name VARCHAR2 (20), 
price NUMBER(10,2),
quantity NUMBER(20) );

INSERT INTO Mobiles VALUES(1001,'Nokia Lumia 520',8000,20);
INSERT INTO Mobiles VALUES(1002,'Samsung Galaxy IV',38000,40);
INSERT INTO Mobiles VALUES(1003,'Sony xperia C',15000,30);
INSERT INTO Mobiles VALUES(1004,'Redmi Note 5',10000,15);
INSERT INTO Mobiles VALUES(1005,'Oppo F9 Pro',20000,10);


CREATE TABLE PurchaseDetails (
purchaseId NUMBER, 
cName vARCHAR2(20), 
mailId VARCHAR2(30),
phoneNo VARCHAR2(20), 
purchaseDate DATE, 
mobileId NUMBER,
CONSTRAINT fk_mobileId FOREIGN KEY(mobileId) references Mobiles(mobileid) );


CREATE SEQUENCE seq_purchaseId 
START WITH 101
INCREMENT BY 1;