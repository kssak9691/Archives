package com.cg.project.beans;
import java.sql.Blob;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class RoomDetails{ 
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int roomId;
	private int roomNo;
	private String roomType; 
	private float perNightRate;
	private boolean availability;
	private Blob photo;
	@ManyToOne
	private Hotel hotel;
	@OneToMany(mappedBy="roomDetails")
	private List<BookingDetails>bookingDetails;
	//constructors parameterized and non parameterized....
	public RoomDetails() {
		super();
	}
	
}