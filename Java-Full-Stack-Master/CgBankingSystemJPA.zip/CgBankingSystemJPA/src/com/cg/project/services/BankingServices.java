package com.cg.project.services;
import java.util.ArrayList;
import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;
public interface BankingServices {
	long  openAccount(String accountType,float initBalance,int pinNumber,String status);
	float depositAmount(long accountNo,float amount);
	float withdrawAmount(long accountNo,float amount,int pinNumber);
	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber);
	Account getAccountDetails(long accountNo);
	ArrayList<Account> getAllAccountDetails();
	ArrayList<Transaction> getAllTransactionDetails(long accountNo);
}