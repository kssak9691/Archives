package com.cg.project.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Hotel{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int hotelId; 
	private String city;  
	private String hotelName; 
	private String address; 
	private String description; 
	private float avgRatePerNight; 
	private String phoneNo; 
	private String rating; 
	private String email; 
	private String fax;
	@OneToMany(mappedBy="hotel")
	private List<RoomDetails>roomDetails;
	@OneToMany(mappedBy="hotel")
	private List<BookingDetails>bookingDetails;
	//constructor parameterized and non parameterized...
	public Hotel() {
		super();
	}
	
}