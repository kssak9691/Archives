package com.capgemini.contactbook.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.exception.ConnectionFailed;
import com.capgemini.contactbook.util.ConnectionProvider;
import com.igate.contactbook.bean.EnquiryBean;
public class ContactBookDAOImpl implements ContactBookDAO{
	private Connection con=ConnectionProvider.getDBConnection();
	Logger logger = Logger.getLogger(ContactBookDAOImpl.class);
	@Override
	public int addEnquiry(EnquiryBean enqry) throws SQLException {
		try {
			if(con==null)
				throw new ConnectionFailed("Server Down");
		}catch(ConnectionFailed e){
			System.out.println("Please try after some time");
		}
		try{con.setAutoCommit(false);
		PreparedStatement s1=con.prepareStatement("INSERT INTO enquiry(enqryid,firstname,lastname,contactno,domain,city) VALUES(enquiries.nextval,?,?,?,?,?)");
		s1.setString(1,enqry.getfName());
		s1.setString(2,enqry.getlName());
		s1.setString(3,enqry.getContactNo());
		s1.setString(4,enqry.getpDomain());
		s1.setString(5,enqry.getpLocation());
		s1.executeUpdate();
		con.commit();
		PreparedStatement s2=con.prepareStatement("SELECT MAX(enqryid) FROM enquiry");
		ResultSet rs=s2.executeQuery();
		rs.next();
		int transaction_id=rs.getInt(1);
		con.commit();
		enqry.setEnqryId(transaction_id);
		return transaction_id;
		} catch (SQLException e) {
			logger.error(e.getMessage()+" "+ e.getErrorCode());
			e.printStackTrace();
			con.rollback();
			System.out.println("System Down. Sorry!!");
			throw e;
		}
		finally{
			con.setAutoCommit(true);
		}
	}
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws SQLException {
		try{con.setAutoCommit(false);
		PreparedStatement s1=con.prepareStatement("SELECT * FROM enquiry WHERE enqryid=?");
		s1.setInt(1,EnquiryID);
		ResultSet rs=s1.executeQuery();
		rs.next();
		EnquiryBean enquiryBean = new EnquiryBean(rs.getInt("enqryid"), rs.getString("firstname"), rs.getString("lastname"), rs.getString("contactno"), rs.getString("city"), rs.getString("domain"));	
		return enquiryBean;
		} catch (SQLException e) {
			logger.error(e.getMessage()+" "+ e.getErrorCode());
			e.printStackTrace();
			con.rollback();
			System.out.println("System Down. Sorry!!");
			throw e;
		}
		finally{
			con.setAutoCommit(true);
		}
	}
}