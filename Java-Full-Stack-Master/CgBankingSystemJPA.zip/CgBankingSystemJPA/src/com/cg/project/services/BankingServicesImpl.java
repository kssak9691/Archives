package com.cg.project.services;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.project.beans.*;
import com.cg.project.daoservices.*;
public class BankingServicesImpl implements BankingServices {
	private AccountDAO accountDAO=new AccountDaoImpl();
	@Override
	public long openAccount(String accountType, float initBalance,int pinNumber,String status) {
		Account account=new Account(pinNumber,accountType,status,initBalance);
		accountDAO.save(account);
		return account.getAccountNo();
	}
	@Override
	public float depositAmount(long accountNo, float amount) {
		Account account = getAccountDetails(accountNo);
		account.setAccountBalance(account.getAccountBalance()+amount);
		Transaction transaction=new Transaction(amount, "deposit", account); 
		accountDAO.update(transaction);
		accountDAO.update(account);
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) {
		Account account = getAccountDetails(accountNo);
		if(account.getAccountBalance()-amount>1000&&account.getPinNumber()==pinNumber){
			account.setAccountBalance(account.getAccountBalance()-amount);
			Transaction transaction=new Transaction(amount, "withdraw", account); 
			accountDAO.update(transaction);
			accountDAO.update(account);
		}
		else
			System.out.println("Insufficient Balance!!Withdrawal Failed");
		return account.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) {
		Account account1 = getAccountDetails(accountNoTo);
		Account account2=getAccountDetails(accountNoFrom);
		if(account2.getAccountBalance()-transferAmount>1000&&account2.getPinNumber()==pinNumber){
			account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
			account2.setAccountBalance(account2.getAccountBalance()-transferAmount);
			Transaction transaction1=new Transaction(transferAmount, "deposit", account1); 
			Transaction transaction2=new Transaction(transferAmount, "deposit", account2); 
			accountDAO.update(transaction1); 
			accountDAO.update(transaction2);
			accountDAO.update(account1);
			accountDAO.update(account2);
		}
		else
			System.out.println("Insufficient Balance!!Withdrawal Failed");
		return false;
	}
	@Override
	public Account getAccountDetails(long accountNo) {
		Account account=accountDAO.getAccountDetails(accountNo);
		return account;	
	}
	@Override
	public ArrayList<Account> getAllAccountDetails() {	
		return accountDAO.getAllAccountDetails();
	}
	@Override
	public ArrayList<Transaction> getAllTransactionDetails(long accountNo) {	
		return accountDAO.getAllTransactionDetails(accountNo);
	}
}