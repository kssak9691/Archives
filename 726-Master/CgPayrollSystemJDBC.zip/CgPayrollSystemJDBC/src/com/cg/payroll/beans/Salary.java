package com.cg.payroll.beans;
public class Salary {
	private int associateID,basicsalary,hra,conveyenceAllowance,otherAllowance,personalAllowance,monthlyTax,epf,companyPf,gratuity,grossSalary,netSalary;
	public Salary() {
		super();
	}
	public Salary(int basicsalary, int epf, int companyPf) {
		super();
		this.basicsalary = basicsalary;
		this.epf = epf;
		this.companyPf = companyPf;
	}
	public Salary(int associateID, int basicsalary, int epf, int companyPf) {
		super();
		this.associateID = associateID;
		this.basicsalary = basicsalary;
		this.epf = epf;
		this.companyPf = companyPf;
	}
	public Salary(int associateID, int basicsalary, int hra,
			int conveyenceAllowance, int otherAllowance, int personalAllowance,
			int monthlyTax, int epf, int companyPf, int gratuity,
			int grossSalary, int netSalary) {
		super();
		this.associateID = associateID;
		this.basicsalary = basicsalary;
		this.hra = hra;
		this.conveyenceAllowance = conveyenceAllowance;
		this.otherAllowance = otherAllowance;
		this.personalAllowance = personalAllowance;
		this.monthlyTax = monthlyTax;
		this.epf = epf;
		this.companyPf = companyPf;
		this.gratuity = gratuity;
		this.grossSalary = grossSalary;
		this.netSalary = netSalary;
	}
	public Salary(int basicsalary, int hra, int conveyenceAllowance,
			int otherAllowance, int personalAllowance, int monthlyTax, int epf,
			int companyPf, int grossSalary, int netSalary) {
		super();
		this.basicsalary = basicsalary;
		this.hra = hra;
		this.conveyenceAllowance = conveyenceAllowance;
		this.otherAllowance = otherAllowance;
		this.personalAllowance = personalAllowance;
		this.monthlyTax = monthlyTax;
		this.epf = epf;
		this.companyPf = companyPf;
		this.grossSalary = grossSalary;
		this.netSalary = netSalary;
	}
	public int getAssociateID() {
		return associateID;
	}
	public void setAssociateID(int associateID) {
		this.associateID = associateID;
	}
	public int getBasicsalary() {
		return basicsalary;
	}
	public void setBasicsalary(int basicsalary) {
		this.basicsalary = basicsalary;
	}
	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getConveyenceAllowance() {
		return conveyenceAllowance;
	}
	public void setConveyenceAllowance(int conveyenceAllowance) {
		this.conveyenceAllowance = conveyenceAllowance;
	}
	public int getOtherAllowance() {
		return otherAllowance;
	}
	public void setOtherAllowance(int otherAllowance) {
		this.otherAllowance = otherAllowance;
	}
	public int getPersonalAllowance() {
		return personalAllowance;
	}
	public void setPersonalAllowance(int personalAllowance) {
		this.personalAllowance = personalAllowance;
	}
	public int getMonthlyTax() {
		return monthlyTax;
	}
	public void setMonthlyTax(int monthlyTax) {
		this.monthlyTax = monthlyTax;
	}
	public int getEpf() {
		return epf;
	}
	public void setEpf(int epf) {
		this.epf = epf;
	}
	public int getCompanyPf() {
		return companyPf;
	}
	public void setCompanyPf(int companyPf) {
		this.companyPf = companyPf;
	}
	public int getGratuity() {
		return gratuity;
	}
	public void setGratuity(int gratuity) {
		this.gratuity = gratuity;
	}
	public int getGrossSalary() {
		return grossSalary;
	}
	public void setGrossSalary(int grossSalary) {
		this.grossSalary = grossSalary;
	}
	public int getNetSalary() {
		return netSalary;
	}
	public void setNetSalary(int netSalary) {
		this.netSalary = netSalary;
	}
	@Override
	public String toString() {
		return "Salary [associateID=" + associateID + ", basicsalary="
				+ basicsalary + ", hra=" + hra + ", conveyenceAllowance="
				+ conveyenceAllowance + ", otherAllowance=" + otherAllowance
				+ ", personalAllowance=" + personalAllowance + ", monthlyTax="
				+ monthlyTax + ", epf=" + epf + ", companyPf=" + companyPf
				+ ", grossSalary=" + grossSalary
				+ ", netSalary=" + netSalary + "]";
	}
}