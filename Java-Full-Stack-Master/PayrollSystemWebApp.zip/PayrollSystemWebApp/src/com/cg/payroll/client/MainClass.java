package com.cg.payroll.client;
import com.cg.payroll.exceptions.*;
import com.cg.payroll.services.*;
public class MainClass {

	public static void main(String[] args) throws AssociateDetailsNotFoundException,PayrollServicesDownException{
		PayrollServices payrollServices = new PayrollServicesImpl();
		int associateId1;
		associateId1=payrollServices.acceptAssociateDetails(25000, "Shravan", "Marutha", "Production", "A.Con", "EXPHM324Q", "shravan@gmail.com", 1121015, "Hdfc", "Hdfc00204", 20000, 1500, 1500);
		System.out.println(associateId1);
		payrollServices.calculateNetSalary(associateId1);
		System.out.println(payrollServices.getAssociateDetails(associateId1));
	}
}